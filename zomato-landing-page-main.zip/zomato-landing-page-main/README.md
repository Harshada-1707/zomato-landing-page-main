# Zomato Landing Page

A simple clone of the Zomato Web page using HTML and CSS.
